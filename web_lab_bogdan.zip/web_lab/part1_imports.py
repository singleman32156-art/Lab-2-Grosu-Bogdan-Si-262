# Laborator: funcții, metode și importuri pe web
# Student: Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Folosit pentru pauzele dintre cereri (regula de lucru) și, la exercițiul 7,
# pentru cronometrare.
import time


# ---------------------------------------------------------------------------
# Exercițiul 1. Primul import
# ---------------------------------------------------------------------------
import requests

print("Exercițiul 1: versiunea requests =", requests.__version__)

import urllib.request

# Explicație: requests este un pachet EXTERN (de la terți): nu vine cu Python,
# deci trebuie descărcat din PyPI cu pip install requests. urllib face parte din
# biblioteca standard, care se instalează automat odată cu Python, așa că nu
# are nevoie de pip install.


# ---------------------------------------------------------------------------
# Exercițiul 2. Două stiluri de import
# ---------------------------------------------------------------------------
print("\nExercițiul 2:")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (requests.get):", response.status_code)

time.sleep(1)  # pauză între cereri

# Același script, rescris cu from requests import get
from requests import get

response = get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (get):", response.status_code)

# Avantajul stilului "import requests": se vede mereu de unde vine funcția
# (requests.get), deci nu există riscul de a suprascrie din greșeală alte nume
# (de exemplu, o funcție proprie numită get).
# Avantajul stilului "from requests import get": codul este mai scurt și mai
# ușor de scris, pentru că nu repetăm numele modulului la fiecare apel.


# ---------------------------------------------------------------------------
# Exercițiul 3. Alias-uri
# ---------------------------------------------------------------------------
print("\nExercițiul 3:")
time.sleep(1)

import requests as rq

response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (rq.get):", response.status_code)

# Un alias face codul mai ușor de citit când numele modulului este lung sau
# când alias-ul este o convenție cunoscută de toți (import numpy as np,
# import pandas as pd).
# Îl face mai greu de citit când alias-ul este scurt și neobișnuit (precum
# rq): cine citește codul trebuie să țină minte ce înseamnă, sau când același
# modul apare sub nume diferite în fișiere diferite.


# ---------------------------------------------------------------------------
# Exercițiul 4. Doar biblioteca standard
# ---------------------------------------------------------------------------
print("\nExercițiul 4:")
time.sleep(1)

request = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-Bogdan"})

try:
    with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:
        print("Status:", answer.status)
        # .read() returnează octeți (bytes); .decode() îi face șir de caractere
        body = answer.read().decode("utf-8", errors="replace")
        print(body[:200])
except urllib.error.URLError as error:
    print("Cererea urllib a eșuat:", error)


# ---------------------------------------------------------------------------
# Exercițiul 5. Priviți în interiorul unui modul
# ---------------------------------------------------------------------------
print("\nExercițiul 5:")
print(dir(requests))

# Trei nume alese din rezultat:
#   - get        -> este o FUNCȚIE (requests.get(url, ...))
#   - Session    -> este o CLASĂ (requests.Session())
#   - exceptions -> este un MODUL (requests.exceptions)
import inspect

print("get este funcție:   ", inspect.isfunction(requests.get))
print("Session este clasă: ", inspect.isclass(requests.Session))
print("exceptions este modul:", inspect.ismodule(requests.exceptions))


# ---------------------------------------------------------------------------
# Exercițiul 6. Citiți documentația
# ---------------------------------------------------------------------------
print("\nExercițiul 6:")
help(requests.get)

# În documentație, parametrul care setează timpul maxim de așteptare este
# timeout (descris la requests.request, la care trimite **kwargs). Îl folosim
# într-o cerere:
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cerere cu timeout =", TIMEOUT, "->", response.status_code)


# ---------------------------------------------------------------------------
# Exercițiul 7. Cronometrarea unei cereri
# ---------------------------------------------------------------------------
print("\nExercițiul 7:")
time.sleep(1)

start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()

print(f"time.perf_counter(): {end - start:.3f} secunde")
print(f"response.elapsed:    {response.elapsed.total_seconds():.3f} secunde")

# Comparație: perf_counter măsoară tot apelul requests.get (creare conexiune,
# trimitere, primirea răspunsului și citirea corpului), deci de obicei iese
# puțin mai mare. response.elapsed măsoară doar intervalul dintre trimiterea
# cererii și sosirea antetelor răspunsului.


# ---------------------------------------------------------------------------
# Exercițiul 8. Când un import eșuează
# ---------------------------------------------------------------------------
print("\nExercițiul 8:")
try:
    import bs4

    print("Modulul bs4 este instalat, versiunea", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")


# ---------------------------------------------------------------------------
# Verificați-vă: care este diferența dintre un modul, un pachet și o bibliotecă?
# ---------------------------------------------------------------------------
# - Modul: un singur fișier .py (sau modul built-in) care conține cod ce poate
#   fi importat (de exemplu time, sau webtools.py făcut de noi).
# - Pachet: un director de module, de obicei cu fișier __init__.py, care permite
#   importuri cu punct (urllib.request, requests.exceptions).
# - Bibliotecă: termen general, nu unul tehnic din Python: o colecție de module
#   și pachete care oferă funcționalități înrudite (biblioteca standard,
#   biblioteca requests).
