# Laborator: funcții, metode și importuri pe web
# Student: Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

import requests

# Pagina principală este descărcată o singură dată și refolosită în
# exercițiile 9-16 și 19.
response = requests.get(BASE_URL, timeout=TIMEOUT)


# ---------------------------------------------------------------------------
# Exercițiul 9. Elementele de bază ale răspunsului
# ---------------------------------------------------------------------------
print("Exercițiul 9:")
print("status_code:", response.status_code)  # atribut (valoare, fără paranteze)
print("ok:", response.ok)                    # atribut (proprietate, fără paranteze)
print("url:", response.url)                  # atribut
print("encoding:", response.encoding)        # atribut


# ---------------------------------------------------------------------------
# Exercițiul 10. Tratarea erorilor cu o metodă
# ---------------------------------------------------------------------------
print("\nExercițiul 10:")
response.raise_for_status()  # metodă: nu face nimic dacă răspunsul este 2xx
print("Pagina principală: raise_for_status() nu a ridicat nicio eroare.")

time.sleep(1)  # pauză între cereri

missing = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
try:
    missing.raise_for_status()
    print("Serverul a răspuns cu codul", missing.status_code, "(nu a fost eroare HTTP).")
except requests.HTTPError:
    print(f"Pagina nu există (cod {missing.status_code}), dar programul continuă.")


# ---------------------------------------------------------------------------
# Exercițiul 11. Toate antetele
# ---------------------------------------------------------------------------
print("\nExercițiul 11:")
for name, value in response.headers.items():
    print(f"{name}: {value}")


# ---------------------------------------------------------------------------
# Exercițiul 12. Metode de dicționar
# ---------------------------------------------------------------------------
print("\nExercițiul 12:")
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type (litere mici):", response.headers.get("content-type", "lipsește"))

# Observație: cu litere mici se obține aceeași valoare. response.headers nu este
# un dicționar obișnuit, ci un CaseInsensitiveDict: numele antetelor se caută
# fără să conteze literele mari/mici (așa cere și standardul HTTP).


# ---------------------------------------------------------------------------
# Exercițiul 13. Înlănțuirea metodelor de șir
# ---------------------------------------------------------------------------
print("\nExercițiul 13:")
count = response.text.lower().count("cyber")
print('Cuvântul "cyber" apare de', count, "ori.")

# Putem înlănțui .lower() și .count() pentru că șirurile de caractere sunt
# imuabile: .lower() nu modifică originalul, ci RETURNEAZĂ un șir nou, iar
# acel șir nou este tot un str și are, la rândul lui, metoda .count().


# ---------------------------------------------------------------------------
# Exercițiul 14. Găsirea titlului
# ---------------------------------------------------------------------------
print("\nExercițiul 14:")
html = response.text
tag_pos = html.find("<title>")
end = html.find("</title>")
if tag_pos == -1 or end == -1:
    print("Pagina nu are tag <title>.")
else:
    start = tag_pos + len("<title>")
    print("Titlu:", html[start:end].strip())


# ---------------------------------------------------------------------------
# Exercițiul 15. Numărarea liniilor
# ---------------------------------------------------------------------------
print("\nExercițiul 15:")
lines = html.splitlines()
print("Număr de linii:", len(lines))
if lines:
    print("Lungimea celei mai lungi linii:", len(max(lines, key=len)))


# ---------------------------------------------------------------------------
# Exercițiul 16. Verificarea HTTPS
# ---------------------------------------------------------------------------
print("\nExercițiul 16:")
if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")


# ---------------------------------------------------------------------------
# Exercițiul 17. Urmărirea redirecționărilor
# ---------------------------------------------------------------------------
print("\nExercițiul 17:")
time.sleep(1)

redirected = requests.get("http://cybercor.org", timeout=TIMEOUT)
if not redirected.history:
    print("Nicio redirecționare.")
for step in redirected.history:
    print(step.status_code, step.url)
print("URL final:", redirected.url)


# ---------------------------------------------------------------------------
# Exercițiul 18. HEAD versus GET
# ---------------------------------------------------------------------------
print("\nExercițiul 18:")
time.sleep(1)
head_response = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
get_response = requests.get(BASE_URL, timeout=TIMEOUT)

print("HEAD: len(content) =", len(head_response.content))
print("GET:  len(content) =", len(get_response.content))

# Diferența: HEAD cere serverului doar antetele (fără corp), deci
# len(response.content) este 0. GET cere și corpul paginii, așa că lungimea este
# egală cu numărul de octeți ai paginii. HEAD este util pentru a verifica rapid
# dacă o pagină există, fără a descărca tot conținutul.


# ---------------------------------------------------------------------------
# Exercițiul 19. Cookie-uri
# ---------------------------------------------------------------------------
print("\nExercițiul 19:")
cookies_found = False
for cookie in response.cookies:
    cookies_found = True
    print("Cookie:", cookie.name, "| secure:", cookie.secure)
if not cookies_found:
    print("Niciun cookie setat")


# ---------------------------------------------------------------------------
# Exercițiul 20. Sesiuni
# ---------------------------------------------------------------------------
print("\nExercițiul 20:")
time.sleep(1)

session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Bogdan"})

# Antetul personalizat se trimite către httpbin.org, NU către cybercor.org.
try:
    echo = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
    sent = echo.json()["headers"].get("User-Agent")
    print("httpbin a primit User-Agent:", sent)
    if sent == "WebLab-Bogdan":
        print("Confirmat: antetul personalizat a fost trimis.")
    else:
        print("Atenție: antetul primit este diferit de cel setat.")
except (requests.RequestException, ValueError, KeyError) as error:
    print("Nu s-a putut verifica antetul la httpbin.org:", error)


# ---------------------------------------------------------------------------
# Verificați-vă: response.text vs response.json()
# ---------------------------------------------------------------------------
# response.text este un ATRIBUT (o proprietate): doar citim o valoare deja
# disponibilă, fără argumente, deci nu se pun paranteze.
# response.json() este o METODĂ: execută o acțiune (interpretează corpul ca
# JSON, ceea ce poate eșua cu o eroare) și se apelează cu paranteze, putând
# primi și argumente.
