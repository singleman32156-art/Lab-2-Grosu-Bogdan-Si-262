# Laborator: funcții, metode și importuri pe web
# Student: Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

import requests


# ---------------------------------------------------------------------------
# Exercițiile 21, 23 și 26. fetch(url, timeout=10)
# (ex. 21: prima versiune, ex. 23: parametru implicit, ex. 26: adnotări de tip)
# ---------------------------------------------------------------------------
def fetch(url: str, timeout: int = 10) -> requests.Response:
    """Descarcă url cu o cerere GET și returnează obiectul răspuns.

    Parametrul timeout (în secunde) are valoarea implicită 10, egală cu TIMEOUT.
    """
    return requests.get(url, timeout=timeout)


print("Exercițiul 21:")
print("Cod de stare:", fetch(BASE_URL).status_code)


# ---------------------------------------------------------------------------
# Exercițiile 22 și 26. get_status(url)
# ---------------------------------------------------------------------------
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


print("\nExercițiul 22:")
for path in ["/", "/robots.txt", "/sitemap.xml"]:
    time.sleep(1)  # pauză între cereri
    print(path, "->", get_status(BASE_URL + path))


# ---------------------------------------------------------------------------
# Exercițiul 23. Parametri impliciți
# ---------------------------------------------------------------------------
print("\nExercițiul 23:")
time.sleep(1)
print("Cu valoarea implicită (10 s):", fetch(BASE_URL).status_code)
time.sleep(1)
print("Cu timeout=3:", fetch(BASE_URL, timeout=3).status_code)


# ---------------------------------------------------------------------------
# Exercițiile 24 și 25. get_title(html) + docstring
# ---------------------------------------------------------------------------
def get_title(html: str) -> str:
    """Returnează titlul paginii (textul dintre <title> și </title>).

    Primește un șir HTML, nu face nicio operație de rețea. Dacă pagina nu are
    titlu, returnează un șir gol.
    """
    start_tag = html.find("<title>")
    end = html.find("</title>")
    if start_tag == -1 or end == -1:
        return ""
    start = start_tag + len("<title>")
    return html[start:end].strip()


print("\nExercițiul 24:")
time.sleep(1)
page = fetch(BASE_URL)  # descărcarea (rețea)
print("Titlu:", get_title(page.text))  # analiza (fără rețea), separată

print("\nExercițiul 25:")
help(get_title)


# ---------------------------------------------------------------------------
# Exercițiul 26. Adnotări de tip
# ---------------------------------------------------------------------------
# Funcțiile de mai sus au deja adnotări de tip (url: str, -> int etc.).
print("\nExercițiul 26:")
try:
    get_status(123)  # type: ignore[arg-type]
except requests.RequestException as error:
    print("get_status(123) a dat eroare:", type(error).__name__, "-", error)

# Observație: adnotările de tip NU ne opresc. Python nu le verifică la rulare:
# apelul get_status(123) a pornit normal, iar eroarea a venit abia din
# requests (URL fără schemă). Adnotările sunt documentație și ajută
# editorul sau instrumente precum mypy să prindă greșeala înainte de rulare.


# ---------------------------------------------------------------------------
# Exercițiul 27. Fără opriri neașteptate
# ---------------------------------------------------------------------------
def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde cu succes, altfel False.

    Orice eroare de rețea (domeniu inexistent, timeout) duce la False, nu la
    oprirea programului.
    """
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


print("\nExercițiul 27:")
for test_url in [
    BASE_URL,
    BASE_URL + "/this-page-does-not-exist",
    "https://this-domain-does-not-exist.invalid",
]:
    print(test_url, "->", page_exists(test_url))
    time.sleep(1)


# ---------------------------------------------------------------------------
# Exercițiul 28. Returnarea unui dicționar
# ---------------------------------------------------------------------------
def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {cale: cod_de_stare} pentru fiecare cale din paths.

    Dacă o cerere eșuează, valoarea pentru acea cale este None. Între cereri
    există o pauză de o secundă.
    """
    results = {}
    for index, path in enumerate(paths):
        if index > 0:
            time.sleep(1)
        try:
            results[path] = get_status(base.rstrip("/") + path)
        except requests.RequestException:
            results[path] = None
    return results


print("\nExercițiul 28:")
print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))


# ---------------------------------------------------------------------------
# Exercițiul 29. Argumente cu nume
# ---------------------------------------------------------------------------
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului name de la url, sau default dacă lipsește."""
    return fetch(url).headers.get(name, default)


print("\nExercițiul 29:")
time.sleep(1)
print("Server:", get_header(BASE_URL, name="Server"))


# ---------------------------------------------------------------------------
# Exercițiul 30. Antete de securitate
# ---------------------------------------------------------------------------
SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    headers = fetch(url).headers  # căutare insensibilă la litere mari/mici
    return {name: name in headers for name in SECURITY_HEADERS}


print("\nExercițiul 30:")
time.sleep(1)
print(security_headers(BASE_URL))


# ---------------------------------------------------------------------------
# Exercițiul 31. Funcții care apelează funcții
# ---------------------------------------------------------------------------
def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers() și returnează un scor, ex. "3/5"."""
    present = sum(1 for found in results.values() if found)
    return f"{present}/{len(results)}"


print("\nExercițiul 31:")
time.sleep(1)
print("Scor:", score_headers(security_headers(BASE_URL)))


# ---------------------------------------------------------------------------
# Exercițiul 32. Două funcții, o sarcină
# ---------------------------------------------------------------------------
def fetch_robots(base: str):
    """Returnează textul fișierului /robots.txt sau None dacă fișierul lipsește."""
    try:
        response = fetch(base.rstrip("/") + "/robots.txt")
    except requests.RequestException:
        return None
    if response.status_code == 200:
        return response.text
    return None


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor Disallow: din robots_text.

    Funcționează și când primește None (returnează lista goală). Liniile
    "Disallow:" fără valoare (care nu interzic nimic) sunt ignorate.
    """
    if not robots_text:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()  # ignorăm comentariile
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


print("\nExercițiul 32:")
time.sleep(1)
robots = fetch_robots(BASE_URL)
print("Căi interzise:", disallowed_paths(robots))
print("Cu None:", disallowed_paths(None))


# ---------------------------------------------------------------------------
# Exercițiul 33. Oricâte argumente
# ---------------------------------------------------------------------------
def response_times(*urls: str) -> dict:
    """Returnează {url: secunde} cu timpul de răspuns pentru fiecare url.

    Primește oricâte adrese. Dacă o cerere eșuează, valoarea este None.
    """
    times = {}
    for index, url in enumerate(urls):
        if index > 0:
            time.sleep(1)
        start = time.perf_counter()
        try:
            fetch(url)
            times[url] = round(time.perf_counter() - start, 3)
        except requests.RequestException:
            times[url] = None
    return times


print("\nExercițiul 33:")
time.sleep(1)
print(response_times(BASE_URL, BASE_URL + "/robots.txt"))


# ---------------------------------------------------------------------------
# Exercițiul 34. Argumente cu nume colectate
# ---------------------------------------------------------------------------
def log(message: str, **details) -> None:
    """Afișează mesajul urmat de fiecare detaliu, în forma: mesaj | cheie=valoare."""
    parts = [message] + [f"{key}={value}" for key, value in details.items()]
    print(" | ".join(parts))


print("\nExercițiul 34:")
log("verificat", url=BASE_URL, status=200)


# ---------------------------------------------------------------------------
# Verificați-vă: print() vs return
# ---------------------------------------------------------------------------
# print() în interiorul unei funcții doar AFIȘEAZĂ valoarea pe ecran; apelantul
# nu o primește (funcția returnează None) și nu o poate folosi mai departe.
# return trimite valoarea înapoi apelantului, care o poate stoca, testa sau
# trimite altei funcții (de ex. score_headers(security_headers(url))).
