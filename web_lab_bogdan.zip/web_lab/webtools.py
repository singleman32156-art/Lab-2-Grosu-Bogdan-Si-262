# Laborator: funcții, metode și importuri pe web
# Student: Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import csv
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import requests

# Exercițiul 47. Constantă de modul, folosită în fetch()
DEFAULT_HEADERS = {"User-Agent": "WebLab-Bogdan"}

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


# ---------------------------------------------------------------------------
# Funcțiile mutate din părțile anterioare (ex. 44)
# ---------------------------------------------------------------------------
def fetch(url: str, timeout: int = 10) -> requests.Response:
    """Descarcă url cu o cerere GET (cu DEFAULT_HEADERS) și returnează răspunsul."""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Returnează titlul paginii (textul dintre <title> și </title>) sau "" dacă lipsește."""
    start_tag = html.find("<title>")
    end = html.find("</title>")
    if start_tag == -1 or end == -1:
        return ""
    return html[start_tag + len("<title>"):end].strip()


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    headers = fetch(url).headers
    return {name: name in headers for name in SECURITY_HEADERS}


# ---------------------------------------------------------------------------
# Alte funcții reutilizabile, necesare pentru raport
# ---------------------------------------------------------------------------
def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers() și returnează un scor, ex. "3/5"."""
    present = sum(1 for found in results.values() if found)
    return f"{present}/{len(results)}"


def check_paths(base: str, paths: list) -> dict:
    """Returnează {cale: cod_de_stare} pentru fiecare cale (None dacă cererea eșuează)."""
    results = {}
    for index, path in enumerate(paths):
        if index > 0:
            time.sleep(1)  # pauză între cereri
        try:
            results[path] = get_status(base.rstrip("/") + path)
        except requests.RequestException:
            results[path] = None
    return results


def fetch_robots(base: str):
    """Returnează textul fișierului /robots.txt sau None dacă fișierul lipsește."""
    try:
        response = fetch(base.rstrip("/") + "/robots.txt")
    except requests.RequestException:
        return None
    if response.status_code == 200:
        return response.text
    return None


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor Disallow: din robots_text (listă goală pentru None)."""
    if not robots_text:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


def extract_links(html: str) -> list:
    """Returnează legăturile (href) din html, fără duplicate, în ordinea apariției."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))


def split_links(links: list, domain: str) -> tuple:
    """Împarte legăturile în (interne, externe) față de domain (doar http/https)."""
    base = "https://" + domain
    internal = []
    external = []
    for link in links:
        full = urljoin(base, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc.lower() == domain.lower():
            internal.append(full)
        else:
            external.append(full)
    return internal, external


def resolve(hostname: str) -> str:
    """Returnează adresa IP (IPv4) a lui hostname."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure_sock:
            cert = secure_sock.getpeercert()
    expires_ts = ssl.cert_time_to_seconds(cert["notAfter"])
    expires = datetime.fromtimestamp(expires_ts, tz=timezone.utc)
    return (expires - datetime.now(timezone.utc)).days


def redirect_chain(url: str) -> list:
    """Returnează lanțul de redirecționări pornind de la varianta http:// a lui url.

    Fiecare element are forma "301 -> https://exemplu.ro/". Lista este goală
    dacă nu există nicio redirecționare.
    """
    http_url = "http://" + urlparse(url).netloc
    response = fetch(http_url)
    steps = []
    hops = response.history + [response]
    for current, following in zip(hops, hops[1:]):
        steps.append(f"{current.status_code} -> {following.url}")
    return steps


# ---------------------------------------------------------------------------
# Exercițiul 49. Raport CSV
# ---------------------------------------------------------------------------
def save_csv_report(base: str, paths: list, filename: str = "report.csv") -> dict:
    """Verifică căile cu check_paths() și salvează rezultatul în filename (CSV).

    Coloane: path, status, checked_at. Returnează dicționarul de la check_paths().
    """
    results = check_paths(base, paths)
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, datetime.now().isoformat()])
    return results


# ---------------------------------------------------------------------------
# Exercițiul 50. Proiect final: raportul site-ului
# ---------------------------------------------------------------------------
def _days_text(days) -> str:
    """Formulează în română numărul de zile rămase (cu sau fără "de")."""
    if days is None:
        return "indisponibil"
    if days < 0:
        return "expirat"
    if days == 0:
        return "0 zile rămase (expiră astăzi)"
    if days == 1:
        return "o zi rămasă"
    rest = days % 100
    if rest == 0 or rest >= 20:
        return f"{days} de zile rămase"
    return f"{days} zile rămase"


def site_report(url: str, json_path: str = "report.json") -> dict:
    """Colectează informații despre url, le afișează și le salvează în json_path.

    Folosește funcțiile din acest modul. Informațiile opționale (IP, certificat,
    robots.txt) devin None / listă goală dacă nu pot fi obținute. Returnează
    dicționarul raportului.
    """
    parsed = urlparse(url)
    hostname = parsed.hostname
    domain = parsed.netloc

    # 1. Codul de stare, URL-ul final, titlul și legăturile
    response = fetch(url)
    title = get_title(response.text)
    internal, external = split_links(extract_links(response.text), domain)

    # 2. Adresa IP
    try:
        ip = resolve(hostname)
    except OSError:
        ip = None

    # 3. Lanțul de redirecționări pornind de la http://
    time.sleep(1)
    try:
        redirects = redirect_chain(url)
    except requests.RequestException:
        redirects = []

    # 4. Scorul antetelor de securitate
    time.sleep(1)
    headers_found = security_headers(url)
    score = score_headers(headers_found)

    # 5. Zilele rămase până la expirarea certificatului (doar pentru https)
    days_left = None
    if parsed.scheme == "https":
        try:
            days_left = cert_days_left(hostname)
        except (OSError, ssl.SSLError, KeyError):
            days_left = None

    # 6. Căile interzise din robots.txt
    time.sleep(1)
    disallowed = disallowed_paths(fetch_robots(url))

    report = {
        "url": url,
        "status_code": response.status_code,
        "final_url": response.url,
        "title": title,
        "ip_address": ip,
        "redirects": redirects,
        "security_score": score,
        "security_headers": headers_found,
        "certificate_days_left": days_left,
        "internal_links": len(internal),
        "external_links": len(external),
        "disallowed_paths": disallowed,
        "checked_at": datetime.now().isoformat(),
    }

    # Afișare
    rows = [
        ("Cod de stare:", response.status_code),
        ("URL final:", response.url),
        ("Titlu:", title or "(fără titlu)"),
        ("Adresă IP:", ip or "indisponibilă"),
        ("Redirecționări:", "; ".join(redirects) if redirects else "nicio redirecționare"),
        ("Scor securitate:", score),
        ("Certificat:", _days_text(days_left)),
        ("Legături:", f"{len(internal)} interne, {len(external)} externe"),
        ("Căi interzise:", ", ".join(disallowed) if disallowed else "niciuna"),
    ]
    print(f"=== Raport site: {url} ===")
    for label, value in rows:
        print(f"{label:<19}{value}")

    with open(json_path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(f"\nSalvat în {json_path}")
    return report


# ---------------------------------------------------------------------------
# Exercițiul 46. Blocul main
# ---------------------------------------------------------------------------
# Condiția __name__ == "__main__" este adevărată doar când fișierul este rulat
# direct (python webtools.py): atunci variabila __name__ are valoarea
# "__main__". Când este importat din main.py (import webtools), __name__ este
# "webtools", deci autotestul NU rulează. Așa modulul poate avea teste proprii
# fără să le execute de fiecare dată când este importat.
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
