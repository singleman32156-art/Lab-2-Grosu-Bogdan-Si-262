# Laborator: funcții, metode și importuri pe web
# Student: Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import hashlib
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests


# ---------------------------------------------------------------------------
# Exercițiul 35. Descompunerea unui URL
# ---------------------------------------------------------------------------
def describe_url(url: str) -> None:
    """Afișează părțile unui URL: schemă, domeniu, cale, interogare, fragment."""
    parts = urlparse(url)
    print("scheme:  ", parts.scheme)
    print("netloc:  ", parts.netloc)
    print("path:    ", parts.path)
    print("query:   ", parts.query)
    print("fragment:", parts.fragment)


# ---------------------------------------------------------------------------
# Exercițiul 36. Compunerea URL-urilor
# ---------------------------------------------------------------------------
def join_links(base: str, links: list) -> list:
    """Transformă legăturile relative din links în URL-uri complete, pornind de la base."""
    return [urljoin(base, link) for link in links]


# ---------------------------------------------------------------------------
# Exercițiul 37. Extragerea legăturilor
# ---------------------------------------------------------------------------
def extract_links(html: str) -> list:
    """Returnează legăturile (href) din html, fără duplicate, în ordinea apariției."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))  # elimină duplicatele păstrând ordinea


# ---------------------------------------------------------------------------
# Exercițiul 38. Interne sau externe?
# ---------------------------------------------------------------------------
def split_links(links: list, domain: str) -> tuple:
    """Împarte legăturile în (interne, externe) față de domain.

    Fiecare legătură este făcută mai întâi absolută cu urljoin(), apoi se
    compară urlparse().netloc cu domain. Legăturile care nu sunt http/https
    (mailto:, javascript: etc.) sunt ignorate.
    """
    base = "https://" + domain
    internal = []
    external = []
    for link in links:
        full = urljoin(base, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc.lower() == domain.lower():
            internal.append(full)
        else:
            external.append(full)
    return internal, external


# ---------------------------------------------------------------------------
# Exercițiul 39. Propriile metode
# ---------------------------------------------------------------------------
class ImageFinder(HTMLParser):
    """Parser HTML care colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Apelată automat de parser la fiecare tag de deschidere.

        HTMLParser transformă numele tag-urilor și ale atributelor în litere
        mici, deci <IMG SRC=...> ajunge aici ca tag == "img". Tag-urile care
        se închid singure (<img ... />) trec tot prin această metodă.
        """
        if tag == "img":
            src = dict(attrs).get("src")
            if src:  # ignorăm <img> fără src
                self.images.append(src)


def test_image_finder() -> None:
    """Testează ImageFinder pe un fragment HTML cu rezultat cunoscut."""
    test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)

    assert finder.images == [
        "/logo.png",                            # imagine obișnuită
        "poza.jpg",                             # tag scris cu majuscule
        "https://cdn.example.com/banner.webp",  # tag care se închide singur
    ], "Parserul nu a găsit exact imaginile așteptate"
    print("Testul a trecut!")


def scan_site_images(url: str) -> None:
    """Rulează ImageFinder pe pagina reală și compară cu numărarea simplă de "<img"."""
    response = requests.get(url, timeout=TIMEOUT)
    finder = ImageFinder()
    finder.feed(response.text)
    print(len(finder.images), "imagini găsite")
    for src in finder.images:
        print(src)
    print('Verificare: response.text.lower().count("<img") =',
          response.text.lower().count("<img"))
    # O listă goală nu e neapărat o greșeală: unele site-uri afișează imaginile
    # prin CSS sau SVG, nu prin tag-uri <img>. Verificați și în browser (Ctrl+U).


# ---------------------------------------------------------------------------
# Exercițiul 40. Amprenta paginii
# ---------------------------------------------------------------------------
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 (hex) a corpului paginii de la url."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()


# Amprentele ar fi diferite dacă pagina s-a modificat între cele două cereri:
# conținut dinamic (oră, contor de vizite, token CSRF, reclame, recomandări),
# o nouă versiune a site-ului sau răspunsuri diferite de la servere diferite.


# ---------------------------------------------------------------------------
# Exercițiul 41. Salvarea în JSON
# ---------------------------------------------------------------------------
def save_headers_json(url: str, filename: str = "headers.json") -> None:
    """Salvează antetele paginii în filename, apoi le reîncarcă și afișează unul."""
    response = requests.get(url, timeout=TIMEOUT)
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(dict(response.headers), file, indent=2)

    with open(filename, encoding="utf-8") as file:
        loaded = json.load(file)
    print("Antete salvate:", len(loaded))
    print("Content-Type:", loaded.get("Content-Type", "lipsește"))


# ---------------------------------------------------------------------------
# Exercițiul 42. Interogare DNS
# ---------------------------------------------------------------------------
def resolve(hostname: str) -> str:
    """Returnează adresa IP (IPv4) a lui hostname."""
    return socket.gethostbyname(hostname)


# ---------------------------------------------------------------------------
# Exercițiul 43. Expirarea certificatului
# ---------------------------------------------------------------------------
def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure_sock:
            cert = secure_sock.getpeercert()
    expires_ts = ssl.cert_time_to_seconds(cert["notAfter"])
    expires = datetime.fromtimestamp(expires_ts, tz=timezone.utc)
    return (expires - datetime.now(timezone.utc)).days


# ---------------------------------------------------------------------------
# Rularea exercițiilor
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("Exercițiul 35:")
    describe_url("https://cybercor.org/path?x=1#top")

    print("\nExercițiul 36:")
    for full_url in join_links(BASE_URL, ["/about", "contact.html", "../index.html"]):
        print(full_url)

    print("\nExercițiul 37:")
    time.sleep(1)
    home = requests.get(BASE_URL, timeout=TIMEOUT)
    all_links = extract_links(home.text)
    print(len(all_links), "legături unice")
    for link in all_links:
        print(" ", link)

    print("\nExercițiul 38:")
    internal_links, external_links = split_links(all_links, "cybercor.org")
    print("Interne:", len(internal_links), "| Externe:", len(external_links))
    for link in external_links:
        print("  extern:", link)

    print("\nExercițiul 39:")
    test_image_finder()
    time.sleep(1)
    scan_site_images(BASE_URL)

    print("\nExercițiul 40:")
    time.sleep(1)
    first = page_fingerprint(BASE_URL)
    time.sleep(1)
    second = page_fingerprint(BASE_URL)
    print("Prima:  ", first)
    print("A doua: ", second)
    print("Identice:", first == second)

    print("\nExercițiul 41:")
    time.sleep(1)
    save_headers_json(BASE_URL)

    print("\nExercițiul 42:")
    print("Adresa IP pentru cybercor.org:", resolve("cybercor.org"))

    print("\nExercițiul 43:")
    print("Zile rămase până la expirarea certificatului:", cert_days_left("cybercor.org"))

    # Verificați-vă: în exercițiul 39, handle_starttag() este apelată de parser,
    # mai exact de metoda feed() din HTMLParser, de fiecare dată când întâlnește
    # un tag de deschidere. Noi doar definim metoda; librăria o apelează (idee
    # numită "callback" sau inversarea controlului).
