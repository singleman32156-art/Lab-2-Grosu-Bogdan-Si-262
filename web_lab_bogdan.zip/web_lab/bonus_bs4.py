# Laborator: funcții, metode și importuri pe web
# Student: Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Bonus: get_title() și extract_links() rescrise cu BeautifulSoup.
# Instalare: pip install beautifulsoup4
try:
    from bs4 import BeautifulSoup
except ImportError:
    raise SystemExit("Instalați modulul cu: pip install beautifulsoup4")

import requests

import webtools  # versiunile scrise de mână, pentru comparație


def get_title_bs(html: str) -> str:
    """Returnează titlul paginii folosind BeautifulSoup (sau "" dacă lipsește)."""
    soup = BeautifulSoup(html, "html.parser")
    if soup.title and soup.title.string:
        return soup.title.string.strip()
    return ""


def extract_links_bs(html: str) -> list:
    """Returnează legăturile (href) din html, fără duplicate, folosind BeautifulSoup."""
    soup = BeautifulSoup(html, "html.parser")
    links = [a["href"] for a in soup.find_all("a", href=True)]
    return list(dict.fromkeys(links))


if __name__ == "__main__":
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    html = response.text

    print("Titlu (manual):        ", repr(webtools.get_title(html)))
    print("Titlu (BeautifulSoup): ", repr(get_title_bs(html)))

    manual = webtools.extract_links(html)
    soup_links = extract_links_bs(html)
    print("Legături (regex):          ", len(manual))
    print("Legături (BeautifulSoup):  ", len(soup_links))
    print("Doar în regex:", sorted(set(manual) - set(soup_links)))
    print("Doar în BeautifulSoup:", sorted(set(soup_links) - set(manual)))

# Comparație:
# - Codul este mult mai scurt: o linie pentru titlu și una pentru legături, în
#   loc de find()/slicing sau expresii regulate.
# - Este mai sigur: BeautifulSoup înțelege HTML-ul. Găsește <title> chiar dacă
#   are atribute sau este scris cu majuscule, găsește href='...' cu apostrof,
#   atribute în orice ordine și ignoră textul care doar arată ca un tag (din
#   comentarii sau scripturi). Varianta cu regex și find() ratează aceste cazuri
#   sau poate da rezultate false.
# La rularea pe cybercor.org: regex-ul a găsit 1 "legătură" (fișierul CSS din
# <link href=...>), iar BeautifulSoup 0, pentru că pagina nu are tag-uri <a>.
# BeautifulSoup face diferența între tipurile de tag-uri, regex-ul nu.