# Laborator: funcții, metode și importuri pe web
# Student: Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import argparse
import time

import requests

# Exercițiul 44. Importul întregului modul: funcțiile se apelează cu prefix
import webtools

# Exercițiul 45. Importul anumitor nume: se apelează direct, fără prefix
from webtools import get_title, security_headers

# Exercițiul 47. Importul constantei de modul
from webtools import DEFAULT_HEADERS

# Ce s-ar întâmpla dacă main.py ar avea și o funcție proprie get_title:
# numele get_title poate indica un singur obiect. Definiția scrisă DUPĂ import
# ar înlocui funcția importată (ultima atribuire câștigă), deci get_title(...)
# ar apela funcția din main.py. Invers, dacă definiția este înaintea importului,
# importul ar înlocui funcția proprie. Nu apare nicio eroare, doar un
# comportament surprinzător. De aceea, importul întreg (webtools.get_title) sau
# un alias (from webtools import get_title as web_title) evită conflictul.


def main() -> int:
    """Rulează laboratorul pe URL-ul primit din linia de comandă. Returnează codul de ieșire."""
    # Exercițiul 48. URL-ul vine din linia de comandă, nu din BASE_URL
    parser = argparse.ArgumentParser(
        description="Raport despre un site web (laborator Python)."
    )
    parser.add_argument("url", help="adresa site-ului, de exemplu https://cybercor.org")
    args = parser.parse_args()
    url = args.url
    if not url.startswith(("http://", "https://")):
        parser.error("URL-ul trebuie să înceapă cu http:// sau https://")

    try:
        # Exercițiul 44
        print("Exercițiul 44 (import webtools):")
        print("Titlu:", webtools.get_title(webtools.fetch(url).text))

        # Exercițiul 45
        print("\nExercițiul 45 (from webtools import ...):")
        time.sleep(1)
        print("Titlu:", get_title(webtools.fetch(url).text))
        time.sleep(1)
        print("Antete de securitate:", security_headers(url))

        # Exercițiul 47
        print("\nExercițiul 47 (constanta DEFAULT_HEADERS):")
        print(DEFAULT_HEADERS)

        # Exercițiul 49
        print("\nExercițiul 49 (report.csv):")
        time.sleep(1)
        results = webtools.save_csv_report(url, ["/", "/robots.txt", "/sitemap.xml"])
        print(results)
        print("Salvat în report.csv")

        # Exercițiul 50
        print()
        time.sleep(1)
        webtools.site_report(url)
    except requests.RequestException as error:
        print("Eroare de rețea:", error)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
